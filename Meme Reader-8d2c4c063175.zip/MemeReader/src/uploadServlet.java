

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.PrintWriter;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.google.cloud.storage.BlobInfo;

import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;

import com.google.cloud.vision.v1.AnnotateImageRequest;
import com.google.cloud.vision.v1.AnnotateImageResponse;
import com.google.cloud.vision.v1.BatchAnnotateImagesResponse;
import com.google.cloud.vision.v1.Feature;
import com.google.cloud.vision.v1.Feature.Type;
import com.google.cloud.vision.v1.Image;
import com.google.cloud.vision.v1.ImageAnnotatorClient;
import com.google.cloud.vision.v1.ImageSource;

/**
 * Servlet implementation class uploadServlet
 */

@WebServlet("/uploadServlet")
@MultipartConfig(location="/tmp", fileSizeThreshold=1024*1024, 
maxFileSize=1024*1024*5, maxRequestSize=1024*1024*5*5)

public class uploadServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	private static Storage storage;
	//private static String jsonAbsPath;
	private static String imgLink;
	
	
	static {
	   // jsonAbsPath = "C:\\Users\\lozy9\\Downloads\\Meme Reader-8d2c4c063175.json";
	    imgLink = null;
	    storage = StorageOptions.newBuilder().build().getService();
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public uploadServlet() {
        super();
    }
    
    

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	//	String bucketName = "jinys-bucket";
	//	Bucket bucket = storage.create(BucketInfo.of(bucketName));
	//	System.out.printf("Bucket %s created.%n", bucket.getName());
		
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Meme Submitted</title>");
		out.println("</head>");
		out.println("<body onload= \"loadAudio()\">");
		out.println("<h1>Textified Your Meme!</h1>");
		readFilePart(request, response, out);
		String memeText, memePhoto, memeAudio;
		try {

			//use vision api
			memeText = detectText(out);
			out.println("<h2>hi</h2>");

			
			memePhoto= detectPhoto();
			
			//use tts api

			memeAudio = googleTextToVoice.TTSFile("Meme Photo. "+ memePhoto + ". Meme Text. " + memeText);
			//uploadFile("memeAudio.mp3", "memeAudio.mp3", "jinys-bucket");

		out.println("<h2> Meme Photo: " + memePhoto +"</h2>");
		out.println("<h2> Meme Text: " + memeText +"</h2>");
		out.println("<audio id = \"memeAudio\" controls>\r\n" + 
//				"  <source src=\"memeAudio.mp3\"  type=\"audio/mpeg\">\r\n" + 
				"</audio>"+
//				"<button onclick=\"playAudio()\" type=\"button\">Play</button>\r\n" + 
//				"<button onclick=\"pauseAudio()\" type=\"button\">Pause</button> \r\n" + 
				"\r\n" + 
				"<script>\r\n" + 
				"var mA = document.getElementById(\"memeAudio\"); \r\n" + 
				"\r\n" + 
				"function playAudio() { \r\n" + 
				"  mA.play(); \r\n" + 
				"} \r\n" + 
				"\r\n" + 
				"function pauseAudio() { \r\n" + 
				"  mA.pause(); \r\n" + 
				"} \r\n" + 
				"function loadAudio() { \r\n" + 
				"  mA.setAttribute('src', 'memeAudio.mp3');\r\n" + 
				"mA.load();" +
				"} \r\n" +
				"</script>");
		
		//out.println( "<br>link: "+imgLink + "<br>");


		out.println("</body>");
		out.println("</html>");
		}
		catch (Exception e) {
				System.out.println("exception2: "+ e.toString() + e.getStackTrace());
				System.out.print(e.getMessage());
		}
	}
	




	protected void readFilePart(HttpServletRequest request, HttpServletResponse response, PrintWriter out) throws ServletException, IOException {
		try {
			boolean format = false;
		    final Part filePart = request.getPart("memeImage");
			String fileName = filePart.getSubmittedFileName();
			// Check extension of file
			if (fileName != null && !fileName.isEmpty() && fileName.contains(".")) {
				final String extension = fileName.substring(fileName.lastIndexOf('.') + 1);
				String[] allowedExt = {"jpg", "jpeg", "png", "gif", "PNG"};
				for (String s : allowedExt) {
				  if (extension.equals(s)) {
					  //out.println("correct format<br>");
					  format = true;
				  }
				}
				if(!format){
					out.println("Error: file must be an image");
					throw new ServletException("file must be an image");
				}
			}			
				filePart.write(fileName);
	
			
			uploadFile(filePart, "jinys-bucket");
			//out.println("<br>... uploaded to: jinys-bucket");			
		}
		catch(Exception e){
			System.out.println("exception1:"+ e.toString());
			
			System.out.print(e.getMessage());
		}
	}
	
	/**
	 * Uploads a file to Google Cloud Storage to the bucket specified in the BUCKET_NAME
	 * environment variable, appending a timestamp to end of the uploaded filename.
	 */
	@SuppressWarnings("deprecation")
	protected String uploadFile(Part filePart, String bucketName) throws IOException {

	  String fileName = filePart.getSubmittedFileName();
	  BlobInfo blobInfo =
	      storage.create(
	          BlobInfo.newBuilder(bucketName, fileName).build(),
	          filePart.getInputStream());	  
	  imgLink = blobInfo.getMediaLink();
	  return blobInfo.getMediaLink();
	}
		
	
	
	
	public static String detectText(PrintWriter out) throws Exception, IOException, FileNotFoundException {
	    List<AnnotateImageRequest> requests = new ArrayList<>();

		ImageSource imgSource = ImageSource.newBuilder().setImageUri(imgLink).build();
	    Image img = Image.newBuilder().setSource(imgSource).build();
	    Feature feat = Feature.newBuilder().setType(Type.TEXT_DETECTION).build();
	    AnnotateImageRequest request =
	        AnnotateImageRequest.newBuilder().addFeatures(feat).setImage(img).build();
	    requests.add(request);

	    try (ImageAnnotatorClient client = ImageAnnotatorClient.create()) {
	      BatchAnnotateImagesResponse response = client.batchAnnotateImages(requests);
	      List<AnnotateImageResponse> responses = response.getResponsesList();

	      for (AnnotateImageResponse res : responses) {
	        if (res.hasError()) {
	        System.out.printf("Error: %s\n", res.getError().getMessage());
	          return "Error:" + res.getError().getMessage();
	        }
	        return res.getTextAnnotationsList().get(0).getDescription() ;
//	        for (EntityAnnotation annotation : res.getTextAnnotationsList()) {
//	          out.printf("Text: %s\n", annotation.getDescription());
//	          //out.printf("Position : %s\n", annotation.getBoundingPoly());
//	        }
	      }
	    }
	    
		catch (Exception e) {
			System.out.println("exception2: "+ e.toString() + e.fillInStackTrace());
			System.out.print(e.getMessage());
	}
		return null;
	  }
	
	
	public static String detectPhoto() throws Exception, IOException, FileNotFoundException {
	    List<AnnotateImageRequest> requests = new ArrayList<>();

		ImageSource imgSource = ImageSource.newBuilder().setImageUri(imgLink).build();
	    Image img = Image.newBuilder().setSource(imgSource).build();
	    Feature feat = Feature.newBuilder().setType(Type.WEB_DETECTION).build();
	    AnnotateImageRequest request =
	        AnnotateImageRequest.newBuilder().addFeatures(feat).setImage(img).build();
	    requests.add(request);

	    try (ImageAnnotatorClient client = ImageAnnotatorClient.create()) {
	      BatchAnnotateImagesResponse response = client.batchAnnotateImages(requests);
	      List<AnnotateImageResponse> responses = response.getResponsesList();
	      System.out.println("num res" + responses.size());
	      for (AnnotateImageResponse res : responses) {
	        if (res.hasError()) {
	        System.out.printf("Error: %s\n", res.getError().getMessage());
	          return "Error:" + res.getError().getMessage();
	        }
	        return res.getWebDetection().getBestGuessLabels(0).getLabel();
	      }
	    }
		return null;
	  }
	
	
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
//	/**
//	 * Extracts the file payload from an HttpServletRequest, checks that the file extension
//	 * is supported and uploads the file to Google Cloud Storage.
//	 */
//	public String getImageUrl(HttpServletRequest req, HttpServletResponse resp,
//	                          final String bucket) throws IOException, ServletException {
//	  Part filePart = req.getPart("file");
//	  final String fileName = filePart.getSubmittedFileName();
//	  String imageUrl = req.getParameter("imageUrl");
//	  // Check extension of file
//	  if (fileName != null && !fileName.isEmpty() && fileName.contains(".")) {
//	    final String extension = fileName.substring(fileName.lastIndexOf('.') + 1);
//	    String[] allowedExt = {"jpg", "jpeg", "png", "gif"};
//	    for (String s : allowedExt) {
//	      if (extension.equals(s)) {
//	        return this.uploadFile(filePart, bucket);
//	      }
//	    }
//	    throw new ServletException("file must be an image");
//	  }
//	  return imageUrl;
//	}
//	
//	/**
//	 * Uploads a file to Google Cloud Storage to the bucket specified in the BUCKET_NAME
//	 * environment variable, appending a timestamp to end of the uploaded filename.
//	 */
//	@SuppressWarnings("deprecation")
//	public String uploadFile(Part filePart, final String bucketName) throws IOException {
//	  DateTimeFormatter dtf = DateTimeFormat.forPattern("-YYYY-MM-dd-HHmmssSSS");
//	  DateTime dt = DateTime.now(DateTimeZone.UTC);
//	  String dtString = dt.toString(dtf);
//	  final String fileName = filePart.getSubmittedFileName() + dtString;
//
//	  // the inputstream is closed by default, so we don't need to close it here
//	  BlobInfo blobInfo =
//	      storage.create(
//	          BlobInfo
//	              .newBuilder(bucketName, fileName)
//	              // Modify access list to allow all users with link to read file
//	              .setAcl(new ArrayList<>(Arrays.asList(Acl.of(User.ofAllUsers(), Role.READER))))
//	              .build(),
//	          filePart.getInputStream());
//	  // return the public download link
//	  return blobInfo.getMediaLink();
//	}
}
