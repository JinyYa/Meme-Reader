import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.google.cloud.storage.BlobInfo;

import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;

import com.google.cloud.vision.v1.AnnotateImageRequest;
import com.google.cloud.vision.v1.AnnotateImageResponse;
import com.google.cloud.vision.v1.BatchAnnotateImagesResponse;
import com.google.cloud.vision.v1.Feature;
import com.google.cloud.vision.v1.Feature.Type;
import com.google.cloud.vision.v1.Image;
import com.google.cloud.vision.v1.ImageAnnotatorClient;
import com.google.cloud.vision.v1.ImageSource;
import com.google.cloud.vision.v1.WebDetection.WebLabel;

/**
 * Servlet implementation class uploadServlet
 */

@WebServlet("/uploadServlet")
@MultipartConfig(location="/tmp", fileSizeThreshold=1024*1024, 
maxFileSize=1024*1024*5, maxRequestSize=1024*1024*5*5)

public class uploadServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	public static Storage storage;
	private static String imgLink;
	public static String audioLink;

	
	static {
	    imgLink = null;
	    storage = StorageOptions.newBuilder().build().getService();
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public uploadServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	//	String bucketName = "jinys-bucket";
	//	Bucket bucket = storage.create(BucketInfo.of(bucketName));
	//	System.out.printf("Bucket %s created.%n", bucket.getName());
		
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Meme Submitted</title>");
		out.println("</head>");
		out.println("<body onload= \"loadAudio()\">");
		out.println("<h1>Textified Your Meme!</h1>");
		readFilePart(request, response, out);
		String memeText, memePhoto, memeAudio;
		try {

			//use vision api
			memeText = detectText(out);
			out.println("<h2>You can listen to the meme here or download it</h2>");

			
			memePhoto= detectPhoto();
			
			//use tts api
			memeAudio = googleTextToVoice.TTSFile("Meme category. "+ memePhoto + ". Meme Text. " + memeText.toLowerCase());
			
		out.println("<h2> Meme category: " + memePhoto +"</h2>");
		out.println("<h2> Meme Text: " + memeText +"</h2>");
		out.println("<audio id = \"memeAudio\" controls>\r\n" + 
				"</audio>" +
				"<img src=\"" + imgLink + "\"alt=\"meme image\">" +
//				"<button on=\"playAudio()\" type=\"button\">Play</button>\r\n" + 
//				"<button onclick=\"pauseAudio()\" type=\"button\">Pause</button> \r\n" + 



				"<a href=\"https://storage.cloud.google.com/jinys-bucket/memeAudio.mp3?hl=ko\">\r\n"
				+ "Download Audio" +
				"</a>\r\n" + 
				"<script>\r\n" + 
				"var mA = document.getElementById(\"memeAudio\"); \r\n" + 
				"\r\n" + 
				"function playAudio() { \r\n" + 
				"  mA.play(); \r\n" + 
				"} \r\n" + 
				"\r\n" + 
				"function pauseAudio() { \r\n" + 
				"  mA.pause(); \r\n" + 
				"} \r\n" + 
				"function loadAudio() { \r\n" + 
				"  mA.setAttribute('src', 'https://storage.cloud.google.com/jinys-bucket/memeAudio.mp3');\r\n" + 
				"mA.load();" +
				"} \r\n" +
				"</script>");
		
		//out.println( "<br>link: "+imgLink + "<br>");


		out.println("</body>");
		out.println("</html>");
		}
		catch (Exception e) {
				System.out.println("exception2: "+ e.toString() + e.getStackTrace());
				System.out.print(e.getMessage());
		}
	}
	
	protected void readFilePart(HttpServletRequest request, HttpServletResponse response, PrintWriter out) throws ServletException, IOException {
		try {
			boolean format = false;
		    final Part filePart = request.getPart("memeImage");
			String fileName = filePart.getSubmittedFileName();
			// Check extension of file
			if (fileName != null && !fileName.isEmpty() && fileName.contains(".")) {
				String extension = fileName.substring(fileName.lastIndexOf('.') + 1);
				String[] allowedExt = {"jpg", "jpeg", "png", "gif", "PNG"};
				for (String s : allowedExt) {
				  if (extension.equals(s)) {
					  //out.println("correct format<br>");
					  format = true;
				  }
				}
				if(!format){
					out.println("Error: file must be an image");
					throw new ServletException("file must be an image");
				}
			}			
				filePart.write(fileName);
	
			
			uploadFile(filePart, "jinys-bucket");
			//out.println("<br>... uploaded to: jinys-bucket");			
		}
		catch(Exception e){
			System.out.println("exception1:"+ e.toString());
			
			System.out.print(e.getMessage());
		}
	}
	
	@SuppressWarnings("deprecation")
	protected String uploadFile(Part filePart, String bucketName) throws IOException {

	  String fileName = filePart.getSubmittedFileName();
	  BlobInfo blobInfo =
	      storage.create(
	          BlobInfo.newBuilder(bucketName, fileName).build(),
	          filePart.getInputStream());	  
	  imgLink = blobInfo.getMediaLink();
	  return blobInfo.getMediaLink();
	}
		
	
	
	
	public static String detectText(PrintWriter out) throws Exception, IOException, FileNotFoundException {
	    List<AnnotateImageRequest> requests = new ArrayList<>();

		ImageSource imgSource = ImageSource.newBuilder().setImageUri(imgLink).build();
	    Image img = Image.newBuilder().setSource(imgSource).build();
	    Feature feat = Feature.newBuilder().setType(Type.TEXT_DETECTION).build();
	    AnnotateImageRequest request =
	        AnnotateImageRequest.newBuilder().addFeatures(feat).setImage(img).build();
	    requests.add(request);

	    try (ImageAnnotatorClient client = ImageAnnotatorClient.create()) {
	      BatchAnnotateImagesResponse response = client.batchAnnotateImages(requests);
	      List<AnnotateImageResponse> responses = response.getResponsesList();

	      for (AnnotateImageResponse res : responses) {
	        if (res.hasError()) {
	        System.out.printf("Error: %s\n", res.getError().getMessage());
	          return "Error:" + res.getError().getMessage();
	        }
	        return res.getTextAnnotationsList().get(0).getDescription() ;

	      }
	    }
	    
		catch (Exception e) {
			System.out.println("exception2: "+ e.toString() + e.fillInStackTrace());
			System.out.print(e.getMessage());
	}
		return null;
	  }
	
	
	public static String detectPhoto() throws Exception, IOException, FileNotFoundException {
	    List<AnnotateImageRequest> requests = new ArrayList<>();

		ImageSource imgSource = ImageSource.newBuilder().setImageUri(imgLink).build();
	    Image img = Image.newBuilder().setSource(imgSource).build();
	    Feature feat = Feature.newBuilder().setType(Type.WEB_DETECTION).build();
	    AnnotateImageRequest request =
	        AnnotateImageRequest.newBuilder().addFeatures(feat).setImage(img).build();
	    requests.add(request);

	    try (ImageAnnotatorClient client = ImageAnnotatorClient.create()) {
	      BatchAnnotateImagesResponse response = client.batchAnnotateImages(requests);
	      List<AnnotateImageResponse> responses = response.getResponsesList();
	      System.out.println("num res" + responses.size());
	      for (AnnotateImageResponse res : responses) {
	        if (res.hasError()) {
	        System.out.printf("Error: %s\n", res.getError().getMessage());
	          return "Error:" + res.getError().getMessage();
	        }
	        
	        String result = "";
	        for(WebLabel l: res.getWebDetection().getBestGuessLabelsList()) {
	        	result += l.getLabel() +";" ;
	        }
	        return result;
	      }
	    }
		return null;
	  }
	
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
	