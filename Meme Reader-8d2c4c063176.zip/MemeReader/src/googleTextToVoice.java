
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.texttospeech.v1.AudioConfig;
import com.google.cloud.texttospeech.v1.AudioEncoding;
import com.google.cloud.texttospeech.v1.SsmlVoiceGender;
import com.google.cloud.texttospeech.v1.SynthesisInput;
import com.google.cloud.texttospeech.v1.SynthesizeSpeechResponse;
import com.google.cloud.texttospeech.v1.TextToSpeechClient;
import com.google.cloud.texttospeech.v1.VoiceSelectionParams;
import com.google.protobuf.ByteString;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.http.Part;

public class googleTextToVoice {
	
	public static String TTSFile(String text) throws FileNotFoundException, IOException {
		
		  try (TextToSpeechClient textToSpeechClient = TextToSpeechClient.create()) {
		      SynthesisInput input = SynthesisInput.newBuilder()
		            .setText(text)
		            .build();
		      VoiceSelectionParams voice = VoiceSelectionParams.newBuilder()
		          .setLanguageCode("en-US")
		          .setSsmlGender(SsmlVoiceGender.MALE)
		          .build();
		
		      AudioConfig audioConfig = AudioConfig.newBuilder()
		          .setAudioEncoding(AudioEncoding.MP3)
		          .build();

		      SynthesizeSpeechResponse response = textToSpeechClient.synthesizeSpeech(input, voice,
		          audioConfig);
		
		      ByteString audioContents = response.getAudioContent();

		      	try (OutputStream out = new FileOutputStream("C:\\Users\\lozy9\\eclipse-workspace\\MemeReader\\WebContent\\memeAudio.mp3")) {
		        out.write(audioContents.toByteArray());
		        uploadFile(audioContents,"jinys-bucket");
		       
		        return "\\memeAudio.mp3"; 
		      }
		 }	
	}
	
	@SuppressWarnings("deprecation")
	protected static String uploadFile(ByteString contents, String bucketName) throws IOException {

	  BlobInfo blobInfo =
			  uploadServlet.storage.create(
	          BlobInfo.newBuilder(bucketName,"memeAudio.mp3").build(), contents.toByteArray()
	          );	  
	  uploadServlet.audioLink = blobInfo.getMediaLink();
	  return blobInfo.getMediaLink();
	}

}